import React, {Component} from 'react';
import { Grid } from 'react-bootstrap';

class Footer extends Component {
	render() {
		return (
            <footer className="footer">
                <Grid>
                    <nav className="pull-left">
                        <ul>
                            <li>
                                <a href="#pablo">
                                   Event Google Map
                                </a>
                            </li>
                            
                        </ul>
                    </nav>
                   
                </Grid>
            </footer>
		);
	}
}

export default Footer;
